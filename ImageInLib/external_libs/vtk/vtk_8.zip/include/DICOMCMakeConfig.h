
#ifndef __DICOMCMakeConfig_h_
#define __DICOMCMakeConfig_h_

/* #undef DICOM_DLL */
#define DICOM_STATIC
#define DICOM_ANSI_STDLIB

#include <vtksys/Configure.hxx>

#endif
